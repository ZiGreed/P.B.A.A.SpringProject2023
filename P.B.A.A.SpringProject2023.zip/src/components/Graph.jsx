//EINAMOJO MENESIO GRAFIKAS KARTU SU PLIUS IR MINUS MYGTUKAIS


// function Graph() {
//     return (  );
// }

// export default Graph;