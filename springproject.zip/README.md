//PROJEKTO STRUKTURA

<APP>
    <NAVIGATION>
        <NavLoginForm>
        <NavMainButtons>
        <NavLogoutButton>
    </NAVIGATION>
    <MAINPAGE>
        <Dashboard>
            <Graph>
            <Calendar>
        </Dashboard>
        <Incomes>
        <Expenses>
    </MAINPAGE>
</APP>
