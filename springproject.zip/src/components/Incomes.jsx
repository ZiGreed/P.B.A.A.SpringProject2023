//PAJAMU PUSLAPIS. JAME BUS GRAFIKAS KURIAME MATOSI VISU METU PAJAMOS SUSKIRSTYTOS PAGAL MENESIUS IR SALIA PAJAMU ISTORIJA(SUVESTINE)


function Incomes() {
    return ( 
        <div>incomes</div>
     );
}

export default Incomes;